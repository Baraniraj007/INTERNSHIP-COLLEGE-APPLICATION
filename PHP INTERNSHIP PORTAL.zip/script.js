document.getElementById("bookingForm").addEventListener("submit", function(event) {

    event.preventDefault();

    let name = document.getElementById("name").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let vehicle = document.getElementById("vehicle").value.trim();
    let vehicleType = document.getElementById("vehicleType").value;
    let serviceType = document.getElementById("serviceType").value;
    let date = document.getElementById("date").value;

    if (name === "") {
        alert("Please enter customer name");
        return;
    }

    if (!/^[0-9]{10}$/.test(phone)) {
        alert("Please enter a valid 10 digit phone number");
        return;
    }

    if (vehicle === "") {
        alert("Please enter vehicle number");
        return;
    }

    if (vehicleType === "") {
        alert("Please select vehicle type");
        return;
    }

    if (serviceType === "") {
        alert("Please select service type");
        return;
    }

    if (date === "") {
        alert("Please select preferred date");
        return;
    }

    document.getElementById("message").innerHTML =
        "Service Booking Confirmed Successfully!";
});

document.getElementById("bookingForm").addEventListener("reset", function() {
    document.getElementById("message").innerHTML = "";
});