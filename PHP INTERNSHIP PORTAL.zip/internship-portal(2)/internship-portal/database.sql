CREATE DATABASE IF NOT EXISTS internship_portal;
USE internship_portal;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('student','company') NOT NULL DEFAULT 'student',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL UNIQUE,
 phone VARCHAR(30),
 college VARCHAR(150),
 skills TEXT,
 resume VARCHAR(255),
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE companies (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL UNIQUE,
 company_name VARCHAR(150) NOT NULL,
 description TEXT,
 website VARCHAR(255),
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE internships (
 id INT AUTO_INCREMENT PRIMARY KEY,
 company_id INT NOT NULL,
 title VARCHAR(200) NOT NULL,
 description TEXT NOT NULL,
 skills VARCHAR(500),
 location VARCHAR(150),
 duration VARCHAR(100),
 stipend DECIMAL(10,2) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

CREATE TABLE applications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 internship_id INT NOT NULL,
 cover_letter TEXT,
 status ENUM('Applied','Under Review','Shortlisted','Interview','Selected','Rejected') NOT NULL DEFAULT 'Applied',
 applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY unique_application(student_id, internship_id),
 FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
 FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE
);

-- Example company/admin account:
-- Generate a password hash in PHP with password_hash("admin123", PASSWORD_DEFAULT)
-- Then insert a company user and company profile.
