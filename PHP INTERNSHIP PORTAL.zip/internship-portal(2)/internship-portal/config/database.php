<?php
// Update these values for your MySQL workspace.
$host = "db01.dbhost.dev";
$port = 5051;
$user = "user_452hrkenr";
$password = "p452hrkenr";
$dbname = "db_452hrkenr";

$conn = new mysqli($host, $user, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>