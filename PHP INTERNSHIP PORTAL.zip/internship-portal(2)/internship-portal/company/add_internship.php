<?php
session_start(); require "../config/database.php";
if(!isset($_SESSION["user_id"])||$_SESSION["role"]!=="company"){header("Location: ../login.php");exit;}
$c=$conn->prepare("SELECT id FROM companies WHERE user_id=?");$c->bind_param("i",$_SESSION["user_id"]);$c->execute();$company=$c->get_result()->fetch_assoc();
if(!$company) die("Company profile not found.");
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $title=trim($_POST["title"]);$description=trim($_POST["description"]);$skills=trim($_POST["skills"]);$location=trim($_POST["location"]);$duration=trim($_POST["duration"]);$stipend=(float)$_POST["stipend"];
    $s=$conn->prepare("INSERT INTO internships(company_id,title,description,skills,location,duration,stipend) VALUES(?,?,?,?,?,?,?)");
    $s->bind_param("isssssd",$company["id"],$title,$description,$skills,$location,$duration,$stipend);$s->execute();
    header("Location: internships.php");exit;
}
?>
<!DOCTYPE html><html><head><title>Add Internship</title><link rel="stylesheet" href="../css/style.css"></head><body><div class="container">
<nav><b>Add Internship</b><span><a href="dashboard.php">Dashboard</a> | <a href="../logout.php">Logout</a></span></nav>
<form method="post" class="form-box"><label>Title</label><input name="title" required><label>Description</label><textarea name="description" required></textarea><label>Skills</label><input name="skills" placeholder="PHP, MySQL, HTML" required><label>Location</label><input name="location" required><label>Duration</label><input name="duration" placeholder="3 Months" required><label>Stipend</label><input type="number" step="0.01" name="stipend" value="0"><button class="btn">Publish Internship</button></form>
</div></body></html>