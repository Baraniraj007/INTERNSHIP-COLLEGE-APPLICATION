<?php
session_start(); require "../config/database.php";
if(!isset($_SESSION["user_id"])||$_SESSION["role"]!=="company"){header("Location: ../login.php");exit;}
$c=$conn->prepare("SELECT id FROM companies WHERE user_id=?");$c->bind_param("i",$_SESSION["user_id"]);$c->execute();$company=$c->get_result()->fetch_assoc();
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $aid=(int)$_POST["application_id"]; $status=$_POST["status"];
    $allowed=["Under Review","Shortlisted","Interview","Selected","Rejected"];
    if(in_array($status,$allowed)){
        $u=$conn->prepare("UPDATE applications a JOIN internships i ON a.internship_id=i.id SET a.status=? WHERE a.id=? AND i.company_id=?");
        $u->bind_param("sii",$status,$aid,$company["id"]);$u->execute();
    }
}
$sql="SELECT a.*,u.name,u.email,s.phone,s.college,s.skills,s.resume,i.title FROM applications a JOIN students s ON a.student_id=s.id JOIN users u ON s.user_id=u.id JOIN internships i ON a.internship_id=i.id WHERE i.company_id=?";
$params=[$company["id"]];$types="i";
if(!empty($_GET["internship_id"])){$sql.=" AND i.id=?";$params[]=(int)$_GET["internship_id"];$types.="i";}
$sql.=" ORDER BY a.applied_at DESC";$stmt=$conn->prepare($sql);$stmt->bind_param($types,...$params);$stmt->execute();$rows=$stmt->get_result();
?>
<!DOCTYPE html><html><head><title>Applicants</title><link rel="stylesheet" href="../css/style.css"></head><body><div class="container">
<nav><b>Applicants</b><span><a href="dashboard.php">Dashboard</a> | <a href="internships.php">Internships</a> | <a href="../logout.php">Logout</a></span></nav>
<div class="table-wrap"><table><tr><th>Student</th><th>Internship</th><th>College</th><th>Skills</th><th>Resume</th><th>Status</th><th>Update</th></tr>
<?php while($r=$rows->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r["name"])?><br><?=htmlspecialchars($r["email"])?></td><td><?=htmlspecialchars($r["title"])?></td><td><?=htmlspecialchars($r["college"])?></td><td><?=htmlspecialchars($r["skills"])?></td><td><?php if($r["resume"]): ?><a href="../uploads/<?=urlencode($r["resume"])?>" target="_blank">View</a><?php endif;?></td>
<td><span class="status"><?=htmlspecialchars($r["status"])?></span></td><td><form method="post"><input type="hidden" name="application_id" value="<?=$r["id"]?>"><select name="status"><option>Under Review</option><option>Shortlisted</option><option>Interview</option><option>Selected</option><option>Rejected</option></select><button class="btn small">Update</button></form></td></tr><?php endwhile; ?>
</table></div></div></body></html>