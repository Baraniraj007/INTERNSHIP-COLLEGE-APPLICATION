
/* ==================================================
   COLLEGE INTERNSHIP PORTAL
   PROFESSIONAL COMPANY / ADMIN DASHBOARD
   ================================================== */

/* ---------- THEME COLOUR VARIABLES ---------- */

:root {
    color-scheme: light;

    --primary: #ea580c;
    --primary-dark: #c2410c;
    --secondary: #dc2626;
    --accent: #fb923c;

    --page-bg: #fff7ed;
    --surface: #ffffff;
    --surface-soft: #ffedd5;

    --text-primary: #292524;
    --text-secondary: #78716c;

    --border-color: #fed7aa;
    --border-size: 1px;
    --border-radius: 16px;

    --success: #15803d;
    --success-bg: #dcfce7;
    --info-bg: #fff7ed;

    --shadow-sm: 0 3px 12px rgba(124, 45, 18, 0.06);
    --shadow-md: 0 10px 28px rgba(124, 45, 18, 0.10);
    --shadow-lg: 0 18px 40px rgba(124, 45, 18, 0.15);

    --transition: 0.25s ease;
}

/* ---------- ALTERNATIVE THEMES ---------- */

/* Theme 1: Corporate Blue */
body.theme-blue {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --secondary: #4f46e5;
    --accent: #60a5fa;
    --page-bg: #f1f5f9;
    --surface-soft: #eff6ff;
    --text-primary: #172554;
    --text-secondary: #64748b;
    --border-color: #dbeafe;
    --info-bg: #eff6ff;
}

/* Theme 2: Emerald Green */
body.theme-green {
    --primary: #059669;
    --primary-dark: #047857;
    --secondary: #0f766e;
    --accent: #34d399;
    --page-bg: #ecfdf5;
    --surface-soft: #d1fae5;
    --text-primary: #064e3b;
    --text-secondary: #64748b;
    --border-color: #a7f3d0;
    --info-bg: #ecfdf5;
}

/* Theme 3: Midnight Purple */
body.theme-purple {
    --primary: #7c3aed;
    --primary-dark: #6d28d9;
    --secondary: #4f46e5;
    --accent: #a78bfa;
    --page-bg: #f5f3ff;
    --surface-soft: #ede9fe;
    --text-primary: #2e1065;
    --text-secondary: #6b7280;
    --border-color: #ddd6fe;
    --info-bg: #f5f3ff;
}

/* Theme 4: Orange to Red (default) */
body.theme-orange {
    --primary: #ea580c;
    --primary-dark: #c2410c;
    --secondary: #dc2626;
    --accent: #fb923c;
    --page-bg: #fff7ed;
    --surface-soft: #ffedd5;
    --text-primary: #292524;
    --text-secondary: #78716c;
    --border-color: #fed7aa;
    --info-bg: #fff7ed;
}

/* ---------- GLOBAL PAGE STYLING ---------- */

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    min-height: 100vh;
    font-family: "Inter", "Segoe UI", Arial, sans-serif;
    font-size: 15px;
    line-height: 1.6;
    color: var(--text-primary);
    background:
        radial-gradient(
            ellipse at top left,
            var(--surface-soft),
            transparent 45%
        ),
        var(--page-bg);
    -webkit-font-smoothing: antialiased;
}

a {
    color: inherit;
}

/* ---------- MAIN DASHBOARD CONTAINER ---------- */

.company-dashboard {
    width: min(1250px, 92%);
    margin: 36px auto;
}

/* ---------- PROFESSIONAL NAVIGATION ---------- */

.company-navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 18px;

    padding: 22px 28px;

    background: var(--surface);
    border: var(--border-size) solid var(--border-color);
    border-top: 4px solid var(--primary);
    border-radius: var(--border-radius);

    box-shadow: var(--shadow-md);
}

.company-brand {
    font-size: 21px;
    font-weight: 800;
    letter-spacing: -0.5px;
    color: var(--text-primary);
}

.company-user {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.welcome-message {
    color: var(--text-secondary);
    font-weight: 600;
}

/* ---------- LOGOUT BUTTON ---------- */

.logout-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 10px 19px;

    color: #ffffff;
    background: linear-gradient(
        135deg,
        var(--primary),
        var(--secondary)
    );

    border: 1px solid transparent;
    border-radius: 9px;

    text-decoration: none;
    font-weight: 700;

    box-shadow: var(--shadow-sm);
    transition:
        transform var(--transition),
        box-shadow var(--transition),
        filter var(--transition);
}

.logout-link:hover {
    color: #ffffff;
    text-decoration: none;
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
    filter: brightness(0.96);
}

.logout-link:focus-visible,
.company-card:focus-visible {
    outline: 3px solid var(--accent);
    outline-offset: 4px;
}

/* ---------- DASHBOARD HEADING ---------- */

.dashboard-heading {
    margin: 42px 0 28px;
}

.dashboard-heading h1 {
    margin: 0 0 10px;
    font-size: clamp(27px, 3vw, 36px);
    line-height: 1.2;
    font-weight: 800;
    letter-spacing: -1px;
    color: var(--text-primary);
}

.dashboard-heading p {
    max-width: 700px;
    margin: 0;
    font-size: 16px;
    color: var(--text-secondary);
    line-height: 1.8;
}

/* ---------- DASHBOARD CARD GRID ---------- */

.company-cards {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 24px;
    align-items: stretch;
}

/* ---------- PROFESSIONAL DASHBOARD CARDS ---------- */

.company-card {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    min-width: 0;
    min-height: 265px;
    padding: 28px;

    background: var(--surface);
    border: var(--border-size) solid var(--border-color);
    border-bottom: 4px solid var(--primary);
    border-radius: var(--border-radius);

    text-decoration: none;
    box-shadow: var(--shadow-sm);

    overflow-wrap: anywhere;

    transition:
        transform var(--transition),
        box-shadow var(--transition),
        border-color var(--transition);
}

.company-card:hover {
    transform: translateY(-6px);
    border-color: var(--accent);
    border-bottom-color: var(--secondary);
    box-shadow: var(--shadow-lg);
    text-decoration: none;
}

.company-card:active {
    transform: translateY(-2px);
}

/* ---------- CARD ICON BOXES ---------- */

.company-card-icon {
    display: flex;
    justify-content: center;
    align-items: center;

    width: 58px;
    height: 58px;
    margin-bottom: 22px;

    border-radius: 15px;
    font-size: 29px;
    font-weight: 800;

    transition: transform var(--transition);
}

.company-card:hover .company-card-icon {
    transform: scale(1.06);
}

.add-icon {
    color: var(--primary-dark);
    background: var(--surface-soft);
    border: 1px solid var(--border-color);
}

.internship-icon {
    color: #15803d;
    background: #dcfce7;
    border: 1px solid #bbf7d0;
}

.applicant-icon {
    color: #6d28d9;
    background: #ede9fe;
    border: 1px solid #ddd6fe;
}

/* ---------- CARD TITLES ---------- */

.company-card h2 {
    margin: 0 0 12px;
    font-size: 21px;
    line-height: 1.35;
    font-weight: 750;
    color: var(--text-primary);
}

/* ---------- CARD DESCRIPTIONS ---------- */

.company-card p {
    margin: 0 0 22px;
    font-size: 15px;
    line-height: 1.8;
    color: var(--text-secondary);
}

/* ---------- CARD ACTION TEXT ---------- */

.company-card-action {
    display: inline-flex;
    align-items: center;
    gap: 6px;

    margin-top: auto;
    padding-top: 8px;

    color: var(--primary);
    font-size: 14px;
    font-weight: 750;

    transition:
        color var(--transition),
        gap var(--transition);
}

.company-card:hover .company-card-action {
    color: var(--secondary);
    gap: 10px;
}

/* ---------- INFORMATION / NOTICE SECTION ---------- */

.dashboard-note {
    margin-top: 32px;
    padding: 24px 26px;

    background: var(--info-bg);
    border: var(--border-size) solid var(--border-color);
    border-left: 5px solid var(--primary);
    border-radius: 12px;

    box-shadow: var(--shadow-sm);
}

.dashboard-note h3 {
    margin: 0 0 8px;
    font-size: 18px;
    font-weight: 750;
    color: var(--text-primary);
}

.dashboard-note p {
    margin: 0;
    line-height: 1.8;
    color: var(--text-secondary);
}

/* ---------- FOOTER ---------- */

.company-footer {
    margin-top: 46px;
    padding: 22px 12px;

    text-align: center;
    color: var(--text-secondary);

    border-top: var(--border-size) solid var(--border-color);
}

.company-footer p {
    margin: 0;
    font-size: 13px;
}

/* ---------- TABLET RESPONSIVENESS ---------- */

@media (max-width: 900px) {
    .company-dashboard {
        width: 94%;
    }

    .company-cards {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 20px;
    }

    .company-navbar {
        padding: 21px;
    }
}

/* ---------- MOBILE RESPONSIVENESS ---------- */

@media (max-width: 600px) {
    .company-dashboard {
        width: 92%;
        margin: 20px auto;
    }

    .company-navbar {
        align-items: flex-start;
        flex-direction: column;
        padding: 19px;
    }

    .company-brand {
        font-size: 19px;
    }

    .company-user {
        width: 100%;
        justify-content: space-between;
        gap: 12px;
    }

    .welcome-message {
        font-size: 14px;
    }

    .dashboard-heading {
        margin: 30px 0 22px;
    }

    .dashboard-heading h1 {
        font-size: 27px;
    }

    .dashboard-heading p {
        font-size: 14px;
    }

    .company-cards {
        grid-template-columns: 1fr;
        gap: 18px;
    }

    .company-card {
        min-height: 225px;
        padding: 23px;
    }

    .dashboard-note {
        margin-top: 24px;
        padding: 19px;
    }

    .company-footer {
        margin-top: 30px;
    }
}

/* ---------- REDUCED MOTION ACCESSIBILITY ---------- */

@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        scroll-behavior: auto !important;
        animation-duration: 0.01ms !important;
        transition-duration: 0.01ms !important;
    }
}
