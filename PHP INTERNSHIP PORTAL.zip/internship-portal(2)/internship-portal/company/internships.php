<?php
session_start(); require "../config/database.php";
if(!isset($_SESSION["user_id"])||$_SESSION["role"]!=="company"){header("Location: ../login.php");exit;}
$c=$conn->prepare("SELECT id FROM companies WHERE user_id=?");$c->bind_param("i",$_SESSION["user_id"]);$c->execute();$company=$c->get_result()->fetch_assoc();
$stmt=$conn->prepare("SELECT i.*,COUNT(a.id) applicants FROM internships i LEFT JOIN applications a ON i.id=a.internship_id WHERE i.company_id=? GROUP BY i.id ORDER BY i.created_at DESC");
$stmt->bind_param("i",$company["id"]);$stmt->execute();$rows=$stmt->get_result();
?>
<!DOCTYPE html><html><head><title>My Internships</title><link rel="stylesheet" href="../css/style.css"></head><body><div class="container">
<nav><b>My Internships</b><span><a href="dashboard.php">Dashboard</a> | <a href="add_internship.php">Add Internship</a> | <a href="../logout.php">Logout</a></span></nav>
<table><tr><th>Title</th><th>Skills</th><th>Location</th><th>Stipend</th><th>Applicants</th></tr>
<?php while($r=$rows->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r["title"])?></td><td><?=htmlspecialchars($r["skills"])?></td><td><?=htmlspecialchars($r["location"])?></td><td>₹<?=number_format($r["stipend"],2)?></td><td><a href="applicants.php?internship_id=<?=$r["id"]?>"><?=$r["applicants"]?></a></td></tr><?php endwhile; ?>
</table></div></body></html>