<?php
session_start();
require "config/database.php";

$message = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $phone = trim($_POST["phone"]);
    $college = trim($_POST["college"]);

    if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        $message = "Enter valid details. Password must contain at least 6 characters.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email=?");
        $check->bind_param("s", $email);
        $check->execute();
        $exists = $check->get_result()->fetch_assoc();

        if ($exists) {
            $message = "Email already registered.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $role = "student";
            $stmt = $conn->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss", $name, $email, $hash, $role);

            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;
                $s = $conn->prepare("INSERT INTO students(user_id,phone,college) VALUES(?,?,?)");
                $s->bind_param("iss", $user_id, $phone, $college);
                $s->execute();
                header("Location: login.php?registered=1");
                exit;
            }
            $message = "Registration failed.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register</title><link rel="stylesheet" href="css/style.css"><script src="js/validation.js"></script></head>
<body>
<div class="container form-box">
<h2>Student Registration</h2>
<?php if ($message): ?><div class="alert"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<form method="post" onsubmit="return validateRegister()">
<label>Name</label><input id="name" name="name" required>
<label>Email</label><input id="email" type="email" name="email" required>
<label>Phone</label><input name="phone">
<label>College</label><input name="college">
<label>Password</label><input id="password" type="password" name="password" required>
<button class="btn" type="submit">Register</button>
</form>
<p>Already registered? <a href="login.php">Login</a></p>
</div>
</body>
</html>