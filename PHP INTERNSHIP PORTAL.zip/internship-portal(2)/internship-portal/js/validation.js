function validateRegister(){
    const name=document.getElementById("name").value.trim();
    const email=document.getElementById("email").value.trim();
    const password=document.getElementById("password").value;
    if(name.length<2){alert("Enter a valid name.");return false;}
    if(!email.includes("@")){alert("Enter a valid email.");return false;}
    if(password.length<6){alert("Password must be at least 6 characters.");return false;}
    return true;
}