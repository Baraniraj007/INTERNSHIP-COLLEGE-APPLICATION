<?php
session_start(); require "../config/database.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") { header("Location: ../login.php"); exit; }
$q=trim($_GET["q"]??""); $location=trim($_GET["location"]??"");
$sql="SELECT i.*,c.company_name FROM internships i JOIN companies c ON i.company_id=c.id WHERE 1";
$params=[];$types="";
if($q!==""){ $sql.=" AND (i.title LIKE ? OR i.skills LIKE ? OR c.company_name LIKE ?)"; $x="%$q%"; $params=[$x,$x,$x]; $types="sss"; }
if($location!==""){ $sql.=" AND i.location LIKE ?"; $x="%$location%"; $params[]=$x;$types.="s"; }
$sql.=" ORDER BY i.created_at DESC";
$stmt=$conn->prepare($sql); if($params)$stmt->bind_param($types,...$params); $stmt->execute(); $rows=$stmt->get_result();
?>
<!DOCTYPE html>
<html><head><title>Internships</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="container">
<nav><b>Internships</b><span><a href="dashboard.php">Dashboard</a> | <a href="applications.php">Applications</a> | <a href="../logout.php">Logout</a></span></nav>
<h2>Search Internships</h2>
<form class="search" method="get"><input name="q" placeholder="Title, skill, company" value="<?=htmlspecialchars($q)?>"><input name="location" placeholder="Location" value="<?=htmlspecialchars($location)?>"><button class="btn">Search</button></form>
<div class="table-wrap"><table><tr><th>Company</th><th>Title</th><th>Skills</th><th>Location</th><th>Duration</th><th>Stipend</th><th>Action</th></tr>
<?php while($r=$rows->fetch_assoc()): ?><tr>
<td><?=htmlspecialchars($r["company_name"])?></td><td><?=htmlspecialchars($r["title"])?></td><td><?=htmlspecialchars($r["skills"])?></td><td><?=htmlspecialchars($r["location"])?></td><td><?=htmlspecialchars($r["duration"])?></td><td>₹<?=number_format($r["stipend"],2)?></td>
<td><a class="btn small" href="apply.php?id=<?=$r["id"]?>">Apply</a></td></tr><?php endwhile; ?>
</table></div></div></body></html>