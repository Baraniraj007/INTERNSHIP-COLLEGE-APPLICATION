<?php
session_start(); require "../config/database.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") { header("Location: ../login.php"); exit; }
$iid=(int)($_GET["id"]??0); $uid=$_SESSION["user_id"];
$stmt=$conn->prepare("SELECT i.*,c.company_name FROM internships i JOIN companies c ON i.company_id=c.id WHERE i.id=?");
$stmt->bind_param("i",$iid);$stmt->execute();$intern=$stmt->get_result()->fetch_assoc();
if(!$intern) die("Internship not found.");
$check=$conn->prepare("SELECT id FROM applications WHERE student_id=(SELECT id FROM students WHERE user_id=?) AND internship_id=?");
$check->bind_param("ii",$uid,$iid);$check->execute();
if($check->get_result()->fetch_assoc()) die("You have already applied. <a href='applications.php'>View applications</a>");
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $s=$conn->prepare("SELECT id FROM students WHERE user_id=?");$s->bind_param("i",$uid);$s->execute();$student=$s->get_result()->fetch_assoc();
    $cover=trim($_POST["cover_letter"]);
    $a=$conn->prepare("INSERT INTO applications(student_id,internship_id,cover_letter,status) VALUES(?,?,?,'Applied')");
    $a->bind_param("iis",$student["id"],$iid,$cover);$a->execute();
    header("Location: applications.php");exit;
}
?>
<!DOCTYPE html><html><head><title>Apply</title><link rel="stylesheet" href="../css/style.css"></head><body><div class="container">
<nav><b>Apply</b><span><a href="internships.php">Back</a> | <a href="../logout.php">Logout</a></span></nav>
<div class="form-box"><h2><?=htmlspecialchars($intern["title"])?></h2><p><b><?=htmlspecialchars($intern["company_name"])?></b> — <?=htmlspecialchars($intern["location"])?></p>
<p><?=nl2br(htmlspecialchars($intern["description"]))?></p>
<form method="post"><label>Cover Letter</label><textarea name="cover_letter" rows="8" required></textarea><button class="btn">Submit Application</button></form>
</div></div></body></html>