<?php
session_start();
require "../config/database.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") { header("Location: ../login.php"); exit; }
?>
<!DOCTYPE html>
<html><head><title>Student Dashboard</title><link rel="stylesheet" href="../css/style.css"></head>
<body>
<div class="container">
<nav><b>Student Portal</b><span>Welcome, <?= htmlspecialchars($_SESSION["name"]) ?> | <a href="../logout.php">Logout</a></span></nav>
<h2>Student Dashboard</h2>
<div class="cards">
<a class="card" href="profile.php"><h3>My Profile</h3><p>Create/update profile and skills.</p></a>
<a class="card" href="internships.php"><h3>Find Internships</h3><p>Search and apply for internships.</p></a>
<a class="card" href="applications.php"><h3>Applications</h3><p>Track application status.</p></a>
</div>
</div></body></html>