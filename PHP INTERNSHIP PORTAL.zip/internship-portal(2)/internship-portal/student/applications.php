<?php
session_start(); require "../config/database.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") { header("Location: ../login.php"); exit; }
$stmt=$conn->prepare("SELECT a.*,i.title,c.company_name FROM applications a JOIN students s ON a.student_id=s.id JOIN internships i ON a.internship_id=i.id JOIN companies c ON i.company_id=c.id WHERE s.user_id=? ORDER BY a.applied_at DESC");
$stmt->bind_param("i",$_SESSION["user_id"]);$stmt->execute();$rows=$stmt->get_result();
?>
<!DOCTYPE html><html><head><title>Applications</title><link rel="stylesheet" href="../css/style.css"></head><body><div class="container">
<nav><b>My Applications</b><span><a href="dashboard.php">Dashboard</a> | <a href="../logout.php">Logout</a></span></nav>
<table><tr><th>Company</th><th>Internship</th><th>Applied</th><th>Status</th></tr>
<?php while($r=$rows->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r["company_name"])?></td><td><?=htmlspecialchars($r["title"])?></td><td><?=htmlspecialchars($r["applied_at"])?></td><td><span class="status"><?=htmlspecialchars($r["status"])?></span></td></tr><?php endwhile; ?>
</table></div></body></html>