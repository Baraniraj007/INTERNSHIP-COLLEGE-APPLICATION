<?php
session_start();
require "../config/database.php";
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") { header("Location: ../login.php"); exit; }

$uid = $_SESSION["user_id"];
$stmt = $conn->prepare("SELECT s.*,u.name,u.email FROM students s JOIN users u ON s.user_id=u.id WHERE s.user_id=?");
$stmt->bind_param("i",$uid); $stmt->execute(); $profile=$stmt->get_result()->fetch_assoc();

$message="";
if ($_SERVER["REQUEST_METHOD"]==="POST") {
    $phone=trim($_POST["phone"]); $college=trim($_POST["college"]); $skills=trim($_POST["skills"]);
    $resume=$profile["resume"] ?? null;
    if (!empty($_FILES["resume"]["name"])) {
        $allowed=["pdf","doc","docx"];
        $ext=strtolower(pathinfo($_FILES["resume"]["name"],PATHINFO_EXTENSION));
        if (in_array($ext,$allowed) && $_FILES["resume"]["size"] <= 5*1024*1024) {
            $dir="../uploads";
            if(!is_dir($dir)) mkdir($dir,0775,true);
            $resume="resume_".$uid."_".time().".".$ext;
            move_uploaded_file($_FILES["resume"]["tmp_name"],$dir."/".$resume);
        } else $message="Resume must be PDF/DOC/DOCX and under 5 MB.";
    }
    if ($message==="") {
        $stmt=$conn->prepare("UPDATE students SET phone=?,college=?,skills=?,resume=? WHERE user_id=?");
        $stmt->bind_param("ssssi",$phone,$college,$skills,$resume,$uid);
        $stmt->execute();
        $message="Profile updated successfully.";
        $profile["phone"]=$phone; $profile["college"]=$college; $profile["skills"]=$skills; $profile["resume"]=$resume;
    }
}
?>
<!DOCTYPE html>
<html><head><title>Profile</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="container">
<nav><b>Student Portal</b><span><a href="dashboard.php">Dashboard</a> | <a href="../logout.php">Logout</a></span></nav>
<h2>My Profile</h2>
<?php if($message): ?><div class="alert"><?=htmlspecialchars($message)?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="form-box">
<label>Name</label><input value="<?=htmlspecialchars($profile["name"])?>" disabled>
<label>Email</label><input value="<?=htmlspecialchars($profile["email"])?>" disabled>
<label>Phone</label><input name="phone" value="<?=htmlspecialchars($profile["phone"]??"")?>">
<label>College</label><input name="college" value="<?=htmlspecialchars($profile["college"]??"")?>">
<label>Skills</label><textarea name="skills" placeholder="PHP, MySQL, Java, HTML"><?=htmlspecialchars($profile["skills"]??"")?></textarea>
<label>Resume</label><input type="file" name="resume" accept=".pdf,.doc,.docx">
<button class="btn">Save Profile</button>
</form>
</div></body></html>