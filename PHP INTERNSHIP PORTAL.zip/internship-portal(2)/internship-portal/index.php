<?php
session_start();
if (isset($_SESSION["user_id"])) {
    $userRole = $_SESSION["role"] ?? "student";
    if ($userRole === "company") {

        header("Location: company/dashboard.php");

    } else {

        header("Location: student/dashboard.php");

    }
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Character encoding -->
    <meta charset="UTF-8">

    <!-- Responsive layout for mobile and desktop -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Browser tab title -->
    <title>College Internship Application Portal</title>

    <!-- External CSS stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Professional font from Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

</head>

<body>

    <!-- =======================================
         MAIN LANDING PAGE
    ======================================== -->

    <main class="container hero">

        <!-- Website brand and introduction -->
        <header class="hero-header">

            <span class="hero-badge">
                COLLEGE CAREER CONNECT
            </span>

            <h1>
                College Internship
                <span>Application Portal</span>
            </h1>

            <p>
                Discover exciting career opportunities, connect with
                companies, apply for internships online, and track
                your application progress in one place.
            </p>

        </header>


        <!-- ===================================
             MAIN ACTION BUTTONS
        ==================================== -->

        <section class="hero-actions">

            <!-- Existing user login -->
            <a href="login.php" class="btn">

                <span>Login to Your Account</span>

                <span aria-hidden="true">&rarr;</span>

            </a>


            <!-- New student registration -->
            <a href="register.php" class="btn secondary">

                <span>Create Student Account</span>

                <span aria-hidden="true">+</span>

            </a>

        </section>


        <!-- ===================================
             PORTAL FEATURES
        ==================================== -->

        <section class="hero-features">

            <article class="feature-item">

                <h2>01</h2>

                <h3>Discover</h3>

                <p>
                    Explore internship opportunities that match
                    your interests and skills.
                </p>

            </article>


            <article class="feature-item">

                <h2>02</h2>

                <h3>Apply</h3>

                <p>
                    Submit applications online and connect with
                    potential employers.
                </p>

            </article>


            <article class="feature-item">

                <h2>03</h2>

                <h3>Track</h3>

                <p>
                    Follow your application status from submission
                    to the final selection.
                </p>

            </article>

        </section>


        <!-- ===================================
             FOOTER
        ==================================== -->

        <footer class="hero-footer">

            <p>
                &copy; <?php echo date("Y"); ?>
                College Internship Application Portal.
                Built for students and companies.
            </p>

        </footer>

    </main>

</body>

</html>

