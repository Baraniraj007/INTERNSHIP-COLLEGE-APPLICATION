COLLEGE INTERNSHIP APPLICATION PORTAL
=====================================

1. Import database.sql into the MySQL workspace.
2. Edit config/database.php with your MySQL host, port, username and password.
3. Start the PHP application from the internship-portal folder.
4. Open index.php in the browser.

Student:
- Register/Login
- Create profile
- Add skills
- Upload resume
- Search/filter internships
- Apply
- Track application status

Company/Admin:
- Login
- Add internships
- View internships
- View applicants
- Update status: Under Review, Shortlisted, Interview, Selected, Rejected

Important:
- Company users must exist in users with role='company' and have a matching row in companies.
- The uploads folder is created automatically when a student uploads a resume.
- For your two-workspace setup, keep MySQL in the MySQL workspace and PHP in the PHP application workspace.
