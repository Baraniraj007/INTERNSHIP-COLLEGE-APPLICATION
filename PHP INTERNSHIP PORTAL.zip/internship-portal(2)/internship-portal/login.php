<?php
session_start();
require "config/database.php";
$message = isset($_GET["registered"]) ? "Registration successful. Please login." : "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id,name,password,role FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["name"] = $user["name"];
        $_SESSION["role"] = $user["role"];
        header("Location: " . ($user["role"] === "company" ? "company/dashboard.php" : "student/dashboard.php"));
        exit;
    }
    $message = "Invalid email or password.";
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title><link rel="stylesheet" href="css/style.css"></head>
<body>
<div class="container form-box">
<h2>Login</h2>
<?php if ($message): ?><div class="alert"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<form method="post">
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required>
<button class="btn" type="submit">Login</button>
</form>
<p>New student? <a href="register.php">Register</a></p>
<p><a href="index.php">Home</a></p>
</div>
</body>
</html>